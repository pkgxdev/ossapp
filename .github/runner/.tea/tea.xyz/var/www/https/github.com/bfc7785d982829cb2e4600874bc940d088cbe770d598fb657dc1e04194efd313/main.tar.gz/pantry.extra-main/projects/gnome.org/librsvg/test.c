#include <librsvg/rsvg.h>

int main(int argc, char *argv[]) {
  RsvgHandle *handle = rsvg_handle_new();
  return 0;
}
