int foo(void) {
  return 42;
}
