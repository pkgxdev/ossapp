main() {
  puts("hi");
  return 0;
}
