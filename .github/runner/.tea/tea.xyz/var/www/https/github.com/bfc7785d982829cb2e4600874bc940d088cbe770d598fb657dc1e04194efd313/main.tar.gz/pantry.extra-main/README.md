![tea](https://tea.xyz/banner.png)

This pantry† is the complement to [pantry.core].

Longer term it will be split out into more pantries, some of which we hope
will be maintained by their own communities.

> † see [pantry.zero] for “what is a pantry”


# Contributing

See the contributing guide in [pantry.zero][pantry.zero/contributing].

[pantry.zero]: https://github.com/teaxyz/pantry.zero
[pantry.zero/contributing]: https://github.com/teaxyz/pantry.zero#contributing
[pantry.core]: https://github.com/teaxyz/pantry.core


# Dependencies

We don’t actually need these, but we do for CI/CD currently.

|   Project   | Version |
|-------------|---------|
| deno.land   | ^1.23   |
