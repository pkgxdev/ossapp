#include <gdk-pixbuf/gdk-pixbuf.h>

int main(int argc, char *argv[]) {
  GType type = gdk_pixbuf_get_type();
  return 0;
}
